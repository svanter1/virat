$(document).ready(function(){
    $('#search').submit(function(e){

        e.preventDefault();
        alert('It works');
    }

 }


